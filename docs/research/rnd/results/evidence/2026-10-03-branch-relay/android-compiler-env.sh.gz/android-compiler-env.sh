export JAVA_HOME=/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home
export ANDROID_JAR=/Users/augustusedem/Library/Android/sdk/platforms/android-36/android.jar
export KOTLINC_BIN=/tmp/loc8-kotlinc-2.1.20
export KOTLIN_STDLIB_JAR=/Users/augustusedem/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-stdlib/2.1.20/aa8ca79cd50578314f6d1180c47cbe14c0fee567/kotlin-stdlib-2.1.20.jar
