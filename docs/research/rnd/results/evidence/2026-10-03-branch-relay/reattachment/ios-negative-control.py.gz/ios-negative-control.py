from pathlib import Path
import tempfile, shutil, subprocess, json
repo=Path('/Users/augustusedem/Loc8-rnd-ble-2026-10-03')
baseline='f7a600bea9d90b3fd96b371c9b59204ddba98760'
workspace=Path(tempfile.mkdtemp(prefix='loc8-reattach-ios-negative-control-',dir='/tmp'))
shutil.copytree(repo/'modules/loc8-mesh/ios',workspace/'modules/loc8-mesh/ios')
shutil.copytree(repo/'tools/mesh-rnd/native-relay',workspace/'tools/mesh-rnd/native-relay')
original=subprocess.run(['git','show',baseline+':modules/loc8-mesh/ios/MeshService.swift'],cwd=repo,capture_output=True,text=True,check=True).stdout
(workspace/'modules/loc8-mesh/ios/MeshService.swift').write_text(original)
command=['node','tools/mesh-rnd/native-relay/run-ios-branch-tests.cjs']
result=subprocess.run(command,cwd=workspace,capture_output=True,text=True)
metadata={'baselineServiceCommit':baseline,'workingTreeFixturesFrom':str(repo),'temporaryWorkspace':str(workspace),'command':command,'expectedRunnerExitCode':1,'observedRunnerExitCode':result.returncode,'scope':'Actual native source + host-only access fixture; original service body; no BLE managers/start/stubs'}
log=json.dumps(metadata,sort_keys=True)+'\n'+result.stdout+'\n'+result.stderr
path=Path('/tmp/loc8-reattach-ios-negative-control.log')
path.write_text(log)
expected=['not ok 21 - active current reattachment','not ok 22 - active branch reattachment','20 passed, 2 failed']
assert result.returncode==1 and all(item in result.stdout for item in expected), log
print(json.dumps(metadata,sort_keys=True))
print('Raw log: '+str(path))
